<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RetailController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard', [
        'store' => 'Filiaal Utrecht Centrum',
        'metrics' => [
            [
                'label' => 'Verkocht deze week',
                'value' => '8.426',
                'change' => '+8,4%',
                'context' => 'producten · vs. vorige week',
                'accent' => 'emerald',
            ],
            [
                'label' => 'Brutowinst deze week',
                'value' => '€ 18.420',
                'change' => '+5,1%',
                'context' => 'na inkoopkosten',
                'accent' => 'blue',
            ],
            [
                'label' => 'Lage voorraad',
                'value' => '12',
                'change' => '4 urgent',
                'context' => 'artikelen onder minimum',
                'accent' => 'amber',
            ],
            [
                'label' => 'Open bestellijst',
                'value' => '7',
                'change' => 'Vandaag 18:00',
                'context' => 'producten klaar voor verzending',
                'accent' => 'violet',
            ],
        ],
        'stockAlerts' => [
            ['name' => 'Halfvolle melk 1L', 'sku' => '8712345678901', 'stock' => '8 stuks', 'minimum' => '24', 'severity' => 'Kritiek'],
            ['name' => 'Volkoren brood', 'sku' => '8712345678902', 'stock' => '14 stuks', 'minimum' => '30', 'severity' => 'Kritiek'],
            ['name' => 'Koffiebonen Arabica', 'sku' => '8712345678903', 'stock' => '6 stuks', 'minimum' => '12', 'severity' => 'Let op'],
            ['name' => 'Afwasmiddel citroen', 'sku' => '8712345678904', 'stock' => '11 stuks', 'minimum' => '18', 'severity' => 'Let op'],
        ],
        'orders' => [
            ['reference' => 'BST-2026-0418', 'supplier' => 'Food Distributeur Noord', 'items' => '18 artikelen', 'status' => 'Verzonden', 'time' => 'Vandaag, 12:00'],
            ['reference' => 'BST-2026-0417', 'supplier' => 'Huishoud Select', 'items' => '9 artikelen', 'status' => 'Concept', 'time' => 'Verzending 18:00'],
            ['reference' => 'BST-2026-0416', 'supplier' => 'Food Distributeur Noord', 'items' => '24 artikelen', 'status' => 'Ontvangen', 'time' => 'Vandaag, 08:42'],
        ],
    ]);
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/voorraad', [RetailController::class, 'inventory'])->name('inventory');
    Route::post('/voorraad/bestellijst', [RetailController::class, 'addToOrder'])->name('inventory.order-items.store');
    Route::get('/klantenservice', [RetailController::class, 'support'])->name('support');
    Route::get('/klantenservice/nieuw', [RetailController::class, 'createTicket'])->name('support.create');
    Route::post('/klantenservice', [RetailController::class, 'storeTicket'])->name('support.store');
    Route::get('/rapportages', [RetailController::class, 'reports'])->name('reports');
    Route::get('/rapportages/export', [RetailController::class, 'exportReports'])->name('reports.export');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
