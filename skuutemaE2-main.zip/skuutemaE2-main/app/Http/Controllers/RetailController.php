<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class RetailController extends Controller
{
    public function inventory(Request $request): View
    {
        $search = $request->string('search')->trim()->toString();
        $stockItems = [
            ['name' => 'Halfvolle melk 1L', 'sku' => '8712345678901', 'category' => 'Vers', 'stock' => 8, 'minimum' => 24, 'supplier' => 'Food Distributeur Noord'],
            ['name' => 'Volkoren brood', 'sku' => '8712345678902', 'category' => 'Bakkerij', 'stock' => 14, 'minimum' => 30, 'supplier' => 'Food Distributeur Noord'],
            ['name' => 'Koffiebonen Arabica', 'sku' => '8712345678903', 'category' => 'Kruidenierswaren', 'stock' => 6, 'minimum' => 12, 'supplier' => 'Food Distributeur Noord'],
            ['name' => 'Afwasmiddel citroen', 'sku' => '8712345678904', 'category' => 'Huishouden', 'stock' => 11, 'minimum' => 18, 'supplier' => 'Huishoud Select'],
            ['name' => 'Bananen per kilo', 'sku' => '8712345678905', 'category' => 'Vers', 'stock' => 42, 'minimum' => 30, 'supplier' => 'Verspartners West'],
        ];

        if ($search !== '') {
            $stockItems = array_values(array_filter(
                $stockItems,
                fn (array $item): bool => str_contains(strtolower($item['name'].' '.$item['sku']), strtolower($search))
            ));
        }

        return view('inventory', [
            'store' => 'Skuutema Retail Stadshart',
            'stockItems' => $stockItems,
            'search' => $search,
            'cutoff' => '18:00',
        ]);
    }

    public function addToOrder(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'sku' => ['required', 'digits:13'],
            'quantity' => ['required', 'integer', 'min:1', 'max:999'],
        ]);

        return to_route('inventory')->with('status', $validated['quantity'].' artikel(s) toegevoegd aan de bestellijst.');
    }

    public function support(): View
    {
        return view('support', [
            'tickets' => [
                ['reference' => 'KL-2026-0184', 'subject' => 'Product niet beschikbaar in de winkel', 'customer' => 'Anoniem', 'channel' => 'Webformulier', 'status' => 'Nieuw', 'priority' => 'Hoog', 'updated' => '12 min geleden'],
                ['reference' => 'KL-2026-0183', 'subject' => 'Vraag over aanbieding koffiebonen', 'customer' => 'Anoniem', 'channel' => 'Telefoon', 'status' => 'In behandeling', 'priority' => 'Normaal', 'updated' => '34 min geleden'],
                ['reference' => 'KL-2026-0181', 'subject' => 'Klacht over lange wachtrij', 'customer' => 'Anoniem', 'channel' => 'E-mail', 'status' => 'Wacht op klant', 'priority' => 'Normaal', 'updated' => '1 uur geleden'],
                ['reference' => 'KL-2026-0179', 'subject' => 'Allergeneninformatie volkoren brood', 'customer' => 'Anoniem', 'channel' => 'Webformulier', 'status' => 'Afgerond', 'priority' => 'Laag', 'updated' => 'Gisteren'],
            ],
        ]);
    }

    public function createTicket(): View
    {
        return view('support-create');
    }

    public function storeTicket(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'subject' => ['required', 'string', 'max:120'],
            'channel' => ['required', 'in:Webformulier,Telefoon,E-mail'],
            'description' => ['required', 'string', 'max:2000'],
        ]);

        return to_route('support')->with('status', 'Melding aangemaakt: '.$validated['subject']);
    }

    public function reports(): View
    {
        return view('reports', [
            'stores' => [
                ['name' => 'Alle filialen', 'sales' => '€ 302.010.000', 'growth' => '+8,4%', 'margin' => '31,2%', 'stock' => '94,6%'],
                ['name' => 'Skuutema Retail Stadshart', 'sales' => '€ 18.420', 'growth' => '+5,1%', 'margin' => '29,8%', 'stock' => '96,2%'],
                ['name' => 'Skuutema Retail Centrum', 'sales' => '€ 17.860', 'growth' => '+3,8%', 'margin' => '28,9%', 'stock' => '93,7%'],
                ['name' => 'Skuutema Retail De Pijp', 'sales' => '€ 16.940', 'growth' => '+11,2%', 'margin' => '32,4%', 'stock' => '95,1%'],
            ],
            'salesByMonth' => [
                ['month' => 'Jun', 'value' => 62],
                ['month' => 'Jul', 'value' => 70],
                ['month' => 'Aug', 'value' => 66],
                ['month' => 'Sep', 'value' => 78],
                ['month' => 'Okt', 'value' => 91],
                ['month' => 'Nov', 'value' => 84],
                ['month' => 'Dec', 'value' => 100],
            ],
        ]);
    }

    public function exportReports(): StreamedResponse
    {
        return response()->streamDownload(function (): void {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['Filiaal', 'Omzet', 'Groei', 'Marge', 'Beschikbaarheid']);
            fputcsv($handle, ['Alle filialen', '€ 302.010.000', '+8,4%', '31,2%', '94,6%']);
            fputcsv($handle, ['Skuutema Retail Stadshart', '€ 18.420', '+5,1%', '29,8%', '96,2%']);
            fputcsv($handle, ['Skuutema Retail Centrum', '€ 17.860', '+3,8%', '28,9%', '93,7%']);
            fputcsv($handle, ['Skuutema Retail De Pijp', '€ 16.940', '+11,2%', '32,4%', '95,1%']);
            fclose($handle);
        }, 'skuutema-rapportage.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
