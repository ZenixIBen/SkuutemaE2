<?php

use App\Models\User;

it('shows the store management dashboard to verified users', function () {
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $response = $this->actingAs($user)->get(route('dashboard'));

    $response
        ->assertOk()
        ->assertSee('Winkeldashboard')
        ->assertSee('Verkocht deze week')
        ->assertSee('Brutowinst deze week')
        ->assertSee('Voorraad die aandacht nodig heeft')
        ->assertSee('Vandaag om 18:00')
        ->assertSee('Food Distributeur Noord');
});

it('requires authentication for the store management dashboard', function () {
    $this->get(route('dashboard'))
        ->assertRedirect(route('login'));
});

it('shows the operational and management workspaces to verified users', function (string $route, string $heading) {
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $this->actingAs($user)
        ->get(route($route))
        ->assertOk()
        ->assertSeeText($heading);
})->with([
    ['inventory', 'Voorraad & bestellingen'],
    ['support', 'Klantenservice'],
    ['reports', "Rapportages & KPI's"],
]);

it('searches inventory and adds items to the order list', function () {
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $this->actingAs($user)
        ->get(route('inventory', ['search' => 'melk']))
        ->assertOk()
        ->assertSeeText('Halfvolle melk 1L')
        ->assertDontSeeText('Volkoren brood');

    $this->actingAs($user)
        ->post(route('inventory.order-items.store'), [
            'sku' => '8712345678901',
            'quantity' => 10,
        ])
        ->assertRedirect(route('inventory'))
        ->assertSessionHas('status');
});

it('creates a customer service ticket and exports reports', function () {
    $user = User::factory()->create([
        'email_verified_at' => now(),
    ]);

    $this->actingAs($user)
        ->post(route('support.store'), [
            'subject' => 'Nieuwe klantvraag',
            'channel' => 'Webformulier',
            'description' => 'Een testmelding.',
        ])
        ->assertRedirect(route('support'))
        ->assertSessionHas('status');

    $this->actingAs($user)
        ->get(route('reports.export'))
        ->assertOk()
        ->assertHeader('content-type', 'text/csv; charset=UTF-8');
});
