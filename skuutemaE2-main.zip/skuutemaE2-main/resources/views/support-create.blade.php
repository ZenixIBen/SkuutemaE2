<x-app-layout>
    <x-slot name="header">
        <div>
            <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Servicecenter</p>
            <h2 class="text-2xl font-semibold text-slate-900 dark:text-white">Nieuwe melding</h2>
        </div>
    </x-slot>
    <div class="min-h-screen bg-slate-50 dark:bg-slate-950">
        <div class="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
            <form method="POST" action="{{ route('support.store') }}" class="flex flex-col gap-6 rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                @csrf
                <div><label for="subject" class="block text-sm font-medium text-slate-700 dark:text-slate-300">Onderwerp</label><input id="subject" name="subject" value="{{ old('subject') }}" required class="mt-2 block w-full rounded-lg border-slate-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"></div>
                <div><label for="channel" class="block text-sm font-medium text-slate-700 dark:text-slate-300">Kanaal</label><select id="channel" name="channel" class="mt-2 block w-full rounded-lg border-slate-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white"><option>Webformulier</option><option>Telefoon</option><option>E-mail</option></select></div>
                <div><label for="description" class="block text-sm font-medium text-slate-700 dark:text-slate-300">Omschrijving</label><textarea id="description" name="description" rows="5" required class="mt-2 block w-full rounded-lg border-slate-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white">{{ old('description') }}</textarea></div>
                @if ($errors->any())<div class="rounded-lg bg-red-50 p-4 text-sm text-red-700 dark:bg-red-400/10 dark:text-red-300">{{ $errors->first() }}</div>@endif
                <div class="flex justify-end gap-3"><a href="{{ route('support') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:text-slate-200">Annuleren</a><button type="submit" class="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-600">Melding opslaan</button></div>
            </form>
        </div>
    </div>
</x-app-layout>
