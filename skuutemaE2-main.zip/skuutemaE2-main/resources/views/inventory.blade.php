<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
            <div>
                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Operationeel beheer</p>
                <h2 class="text-2xl font-semibold text-slate-900 dark:text-white">Voorraad & bestellingen</h2>
            </div>
            <span class="text-sm text-slate-500 dark:text-slate-400">{{ $store }}</span>
        </div>
    </x-slot>

    <div class="min-h-screen bg-slate-50 dark:bg-slate-950">
        <div class="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-8 sm:px-6 lg:px-8">
            <div class="grid gap-4 sm:grid-cols-3">
                <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                    <p class="text-sm text-slate-500 dark:text-slate-400">Artikelen in assortiment</p>
                    <p class="mt-2 text-3xl font-semibold text-slate-900 dark:text-white">2.486</p>
                </div>
                <div class="rounded-xl border border-amber-200 bg-amber-50 p-5 shadow-sm dark:border-amber-900/50 dark:bg-amber-400/10">
                    <p class="text-sm text-amber-800 dark:text-amber-300">Onder minimumvoorraad</p>
                    <p class="mt-2 text-3xl font-semibold text-amber-950 dark:text-amber-200">12</p>
                </div>
                <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-5 shadow-sm dark:border-emerald-900/50 dark:bg-emerald-400/10">
                    <p class="text-sm text-emerald-800 dark:text-emerald-300">Volgend verzendmoment</p>
                    <p class="mt-2 text-3xl font-semibold text-emerald-950 dark:text-emerald-200">{{ $cutoff }}</p>
                </div>
            </div>

            <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                        <h2 class="font-semibold text-slate-900 dark:text-white">Artikel zoeken</h2>
                        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Scan een barcode met de mobiele app of zoek op productnaam.</p>
                    </div>
                    <form method="GET" action="{{ route('inventory') }}" class="flex w-full gap-2 md:max-w-md">
                        <input name="search" value="{{ $search }}" type="search" placeholder="EAN of productnaam" class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-emerald-500 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-800 dark:text-white">
                        <button type="submit" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700 dark:bg-emerald-500 dark:text-slate-950 dark:hover:bg-emerald-400">Zoeken</button>
                    </form>
                </div>
            </section>

            @if (session('status'))
                <div role="status" class="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-400/10 dark:text-emerald-300">{{ session('status') }}</div>
            @endif

            <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
                <div class="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
                    <div>
                        <h2 class="font-semibold text-slate-900 dark:text-white">Voorraadstatus</h2>
                        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Voeg lage voorraad direct toe aan de bestellijst.</p>
                    </div>
                    <a href="{{ route('inventory') }}" class="hidden rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-600 sm:inline-flex">Bestellijst bekijken</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full min-w-[760px] text-left text-sm">
                        <thead class="bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:bg-slate-950/50 dark:text-slate-400">
                            <tr><th class="px-5 py-3 font-medium">Artikel</th><th class="px-5 py-3 font-medium">Categorie</th><th class="px-5 py-3 font-medium">Voorraad</th><th class="px-5 py-3 font-medium">Leverancier</th><th class="px-5 py-3"></th></tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                            @foreach ($stockItems as $item)
                                @php($isLow = $item['stock'] < $item['minimum'])
                                <tr>
                                    <td class="px-5 py-4"><p class="font-medium text-slate-900 dark:text-white">{{ $item['name'] }}</p><p class="mt-1 text-xs text-slate-500 dark:text-slate-400">EAN {{ $item['sku'] }}</p></td>
                                    <td class="px-5 py-4 text-slate-600 dark:text-slate-300">{{ $item['category'] }}</td>
                                    <td class="px-5 py-4"><span class="font-semibold {{ $isLow ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400' }}">{{ $item['stock'] }}</span><span class="text-slate-500"> / {{ $item['minimum'] }}</span></td>
                                    <td class="px-5 py-4 text-slate-600 dark:text-slate-300">{{ $item['supplier'] }}</td>
                                    <td class="px-5 py-4 text-right">
                                        <form method="POST" action="{{ route('inventory.order-items.store') }}" class="flex items-center justify-end gap-2">
                                            @csrf
                                            <input type="hidden" name="sku" value="{{ $item['sku'] }}">
                                            <input name="quantity" type="number" min="1" value="{{ max(1, $item['minimum'] - $item['stock']) }}" class="w-20 rounded-lg border-slate-300 px-2 py-2 text-xs dark:border-slate-700 dark:bg-slate-800 dark:text-white">
                                            <button type="submit" class="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">Toevoegen</button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
