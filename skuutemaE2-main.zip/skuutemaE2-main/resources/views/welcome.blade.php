<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Skuutema Retail</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600,700&display=swap" rel="stylesheet">
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="bg-slate-50 font-sans text-slate-900 antialiased">
        <header class="border-b border-slate-200 bg-white">
            <div class="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
                <a href="{{ url('/') }}" class="flex items-center gap-2 text-lg font-bold">
                    <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500 text-white">S</span>
                    <span>Skuutema Retail</span>
                </a>

                @auth
                    <a href="{{ route('dashboard') }}" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">
                        Dashboard
                    </a>
                @else
                    <a href="{{ route('login') }}" class="text-sm font-semibold text-slate-600 hover:text-slate-900">
                        Inloggen
                    </a>
                @endauth
            </div>
        </header>

        <main>
            <section class="mx-auto grid max-w-6xl gap-12 px-5 py-20 md:grid-cols-2 md:items-center md:py-28">
                <div>
                    <p class="text-sm font-semibold uppercase tracking-wide text-emerald-600">Winkelbeheer zonder gedoe</p>
                    <h1 class="mt-4 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
                        Alles voor je winkel op één plek.
                    </h1>
                    <p class="mt-5 max-w-lg text-lg leading-8 text-slate-600">
                        Houd voorraad, bestellingen en winkelresultaten eenvoudig bij met Skuutema Retail.
                    </p>
                    <div class="mt-8">
                        <a href="{{ route('login') }}" class="inline-flex rounded-lg bg-emerald-500 px-5 py-3 text-sm font-bold text-white hover:bg-emerald-600">
                            Naar het dashboard
                            <span class="ml-2" aria-hidden="true">→</span>
                        </a>
                    </div>
                </div>

                <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                        <div>
                            <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Vandaag</p>
                            <p class="mt-1 font-semibold">Filiaal Utrecht Centrum</p>
                        </div>
                        <span class="flex items-center gap-2 text-sm text-emerald-600">
                            <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                            Actueel
                        </span>
                    </div>

                    <div class="grid grid-cols-2 gap-4 py-5">
                        <div>
                            <p class="text-sm text-slate-500">Verkocht deze week</p>
                            <p class="mt-1 text-2xl font-bold">8.426</p>
                        </div>
                        <div>
                            <p class="text-sm text-slate-500">Lage voorraad</p>
                            <p class="mt-1 text-2xl font-bold text-amber-600">12</p>
                        </div>
                    </div>

                    <div class="rounded-lg bg-slate-50 p-4">
                        <div class="flex items-center justify-between">
                            <p class="font-medium">Volgend bestelmoment</p>
                            <p class="font-semibold text-emerald-600">18:00</p>
                        </div>
                        <p class="mt-1 text-sm text-slate-500">Levering morgen vóór 10:00</p>
                    </div>
                </div>
            </section>

            <section class="border-y border-slate-200 bg-white">
                <div class="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-3">
                    <div>
                        <p class="text-lg font-semibold">Voorraad</p>
                        <p class="mt-2 text-sm leading-6 text-slate-600">Zie direct welke producten bijna op zijn.</p>
                    </div>
                    <div>
                        <p class="text-lg font-semibold">Bestellingen</p>
                        <p class="mt-2 text-sm leading-6 text-slate-600">Werk met de vaste verzendmomenten van 12:00 en 18:00.</p>
                    </div>
                    <div>
                        <p class="text-lg font-semibold">Inzicht</p>
                        <p class="mt-2 text-sm leading-6 text-slate-600">Bekijk verkoop en winst in een duidelijk overzicht.</p>
                    </div>
                </div>
            </section>
        </main>

        <footer class="mx-auto flex max-w-6xl justify-between px-5 py-6 text-sm text-slate-500">
            <span>© {{ date('Y') }} Skuutema Retail</span>
            <span>Voorraad. Inzicht. Groei.</span>
        </footer>
    </body>
</html>
