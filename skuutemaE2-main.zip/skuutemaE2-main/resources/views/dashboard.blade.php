<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Operationeel overzicht</p>
                <h2 class="text-2xl font-semibold leading-tight text-slate-900 dark:text-white">
                    Winkeldashboard
                </h2>
            </div>

            <div class="flex items-center gap-3">
                <div class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-600 shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    <span class="mr-2 inline-block h-2 w-2 rounded-full bg-emerald-500"></span>
                    Live bijgewerkt om 14:32
                </div>
                <a href="{{ route('inventory') }}" class="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 dark:bg-emerald-500 dark:text-slate-950 dark:hover:bg-emerald-400">
                    Nieuwe bestelling
                </a>
            </div>
        </div>
    </x-slot>

    <div class="min-h-screen bg-slate-50 dark:bg-slate-950">
        <div class="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-8 sm:px-6 lg:px-8">
            <div class="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
                <div>
                    <p class="text-sm text-slate-500 dark:text-slate-400">Dinsdag 8 oktober 2026</p>
                    <h1 class="mt-1 text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">
                        Goedemiddag, {{ Auth::user()->name }}
                    </h1>
                    <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">{{ $store }}</p>
                </div>
                <a href="{{ route('reports') }}" class="text-sm font-semibold text-emerald-700 hover:text-emerald-600 dark:text-emerald-400 dark:hover:text-emerald-300">
                    Bekijk alle rapportages <span aria-hidden="true">→</span>
                </a>
            </div>

            <section aria-labelledby="performance-heading">
                <h2 id="performance-heading" class="sr-only">Prestatieoverzicht</h2>
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    @foreach ($metrics as $metric)
                        <article class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                            <div class="flex items-start justify-between gap-3">
                                <p class="text-sm font-medium text-slate-500 dark:text-slate-400">{{ $metric['label'] }}</p>
                                <span class="rounded-full px-2 py-1 text-xs font-semibold {{ match ($metric['accent']) {
                                    'emerald' => 'bg-emerald-50 text-emerald-700 dark:bg-emerald-400/10 dark:text-emerald-400',
                                    'blue' => 'bg-blue-50 text-blue-700 dark:bg-blue-400/10 dark:text-blue-400',
                                    'amber' => 'bg-amber-50 text-amber-700 dark:bg-amber-400/10 dark:text-amber-400',
                                    default => 'bg-violet-50 text-violet-700 dark:bg-violet-400/10 dark:text-violet-400',
                                } }}">
                                    {{ $metric['change'] }}
                                </span>
                            </div>
                            <p class="mt-4 text-3xl font-semibold tracking-tight text-slate-900 dark:text-white">{{ $metric['value'] }}</p>
                            <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">{{ $metric['context'] }}</p>
                        </article>
                    @endforeach
                </div>
            </section>

            <div class="grid grid-cols-1 gap-6 xl:grid-cols-5">
                <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm xl:col-span-3 dark:border-slate-800 dark:bg-slate-900" aria-labelledby="stock-heading">
                    <div class="flex items-center justify-between gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-800">
                        <div>
                            <h2 id="stock-heading" class="font-semibold text-slate-900 dark:text-white">Voorraad die aandacht nodig heeft</h2>
                            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Artikelen onder het ingestelde minimum</p>
                        </div>
                        <a href="{{ route('inventory') }}" class="text-sm font-semibold text-emerald-700 hover:text-emerald-600 dark:text-emerald-400">Voorraad bekijken</a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full min-w-[620px] text-left text-sm">
                            <thead class="bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:bg-slate-950/50 dark:text-slate-400">
                                <tr>
                                    <th scope="col" class="px-5 py-3 font-medium">Artikel</th>
                                    <th scope="col" class="px-5 py-3 font-medium">Op voorraad</th>
                                    <th scope="col" class="px-5 py-3 font-medium">Minimum</th>
                                    <th scope="col" class="px-5 py-3 font-medium">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                                @foreach ($stockAlerts as $alert)
                                    <tr>
                                        <td class="px-5 py-4">
                                            <p class="font-medium text-slate-900 dark:text-white">{{ $alert['name'] }}</p>
                                            <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">EAN {{ $alert['sku'] }}</p>
                                        </td>
                                        <td class="px-5 py-4 font-semibold text-slate-900 dark:text-white">{{ $alert['stock'] }}</td>
                                        <td class="px-5 py-4 text-slate-500 dark:text-slate-400">{{ $alert['minimum'] }} stuks</td>
                                        <td class="px-5 py-4">
                                            <span class="inline-flex rounded-full px-2.5 py-1 text-xs font-semibold {{ $alert['severity'] === 'Kritiek' ? 'bg-red-50 text-red-700 dark:bg-red-400/10 dark:text-red-400' : 'bg-amber-50 text-amber-700 dark:bg-amber-400/10 dark:text-amber-400' }}">
                                                {{ $alert['severity'] }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </section>

                <section class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm xl:col-span-2 dark:border-slate-800 dark:bg-slate-900" aria-labelledby="delivery-heading">
                    <div class="flex items-start justify-between gap-4">
                        <div>
                            <h2 id="delivery-heading" class="font-semibold text-slate-900 dark:text-white">Volgende levering</h2>
                            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Verwacht morgen vóór 10:00</p>
                        </div>
                        <span class="rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-400/10 dark:text-emerald-400">Onderweg</span>
                    </div>
                    <div class="mt-6 flex items-center gap-4">
                        <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-400/10 dark:text-emerald-400" aria-hidden="true">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M3 16.5V6.75A1.75 1.75 0 014.75 5h9.5A1.75 1.75 0 0116 6.75V16.5M16 9h2.25a1.75 1.75 0 011.4.7l1.6 2.13v4.67H16M7 18.5a2 2 0 11-4 0 2 2 0 014 0zm12 0a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                        </div>
                        <div>
                            <p class="font-semibold text-slate-900 dark:text-white">Food Distributeur Noord</p>
                            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">24 artikelen · BST-2026-0418</p>
                        </div>
                    </div>
                    <div class="mt-6 rounded-lg bg-slate-50 p-4 dark:bg-slate-950/50">
                        <div class="flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
                            <span>Besteld</span>
                            <span>Onderweg</span>
                            <span>Geleverd</span>
                        </div>
                        <div class="relative mt-3 h-2 rounded-full bg-slate-200 dark:bg-slate-700">
                            <div class="h-2 w-2/3 rounded-full bg-emerald-500"></div>
                            <span class="absolute left-2/3 top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white bg-emerald-500 dark:border-slate-900"></span>
                        </div>
                    </div>
                    <div class="mt-4 grid grid-cols-2 gap-3">
                        <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                            <p class="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">Volgend verzendmoment</p>
                            <p class="mt-1 font-semibold text-slate-900 dark:text-white">Vandaag om 18:00</p>
                        </div>
                        <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                            <p class="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">Levering</p>
                            <p class="mt-1 font-semibold text-slate-900 dark:text-white">Morgen vóór 10:00</p>
                        </div>
                    </div>
                </section>
            </div>

            <section class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900" aria-labelledby="orders-heading">
                <div class="flex items-center justify-between gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-800">
                    <div>
                        <h2 id="orders-heading" class="font-semibold text-slate-900 dark:text-white">Recente bestellingen</h2>
                        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Overzicht van bestellingen en verzendmomenten</p>
                    </div>
                    <a href="{{ route('inventory') }}" class="text-sm font-semibold text-emerald-700 hover:text-emerald-600 dark:text-emerald-400">Alle bestellingen</a>
                </div>
                <div class="grid grid-cols-1 divide-y divide-slate-100 md:grid-cols-3 md:divide-x md:divide-y-0 dark:divide-slate-800">
                    @foreach ($orders as $order)
                        <article class="flex flex-col gap-4 p-5">
                            <div class="flex items-start justify-between gap-3">
                                <p class="font-semibold text-slate-900 dark:text-white">{{ $order['reference'] }}</p>
                                <span class="text-xs font-semibold {{ $order['status'] === 'Concept' ? 'text-amber-600 dark:text-amber-400' : ($order['status'] === 'Ontvangen' ? 'text-slate-500 dark:text-slate-400' : 'text-emerald-600 dark:text-emerald-400') }}">{{ $order['status'] }}</span>
                            </div>
                            <div>
                                <p class="text-sm text-slate-700 dark:text-slate-300">{{ $order['supplier'] }}</p>
                                <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">{{ $order['items'] }} · {{ $order['time'] }}</p>
                            </div>
                            <a href="{{ route('inventory') }}" class="mt-auto text-sm font-semibold text-slate-700 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white">Details bekijken <span aria-hidden="true">→</span></a>
                        </article>
                    @endforeach
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
